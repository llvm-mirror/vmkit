package ijvm.tests.A;

public interface A
{
	public void performA();
	public Token getToken();
}
