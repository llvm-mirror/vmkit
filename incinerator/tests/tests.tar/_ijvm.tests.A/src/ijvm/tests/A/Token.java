package ijvm.tests.A;

public interface Token
{
	public int getValue();
}
