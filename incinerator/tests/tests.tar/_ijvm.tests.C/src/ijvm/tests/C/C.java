package ijvm.tests.C;

public interface C
{
	public void performC();
	public void registerObject(Object o);
}
