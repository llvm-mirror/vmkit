package ijvm.tests.B;

public interface B
{
	public void performB();
}
