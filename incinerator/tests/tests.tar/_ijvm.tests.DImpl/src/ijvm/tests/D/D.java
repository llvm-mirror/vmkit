package ijvm.tests.D;

public interface D
{
	public void performD();
}
